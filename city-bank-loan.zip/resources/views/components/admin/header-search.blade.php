<button class="flex items-center xl:text-sm text-lg xl:text-slate-400 text-slate-800 dark:text-slate-300 focus:outline-none focus:shadow-none px-1 space-x-3
rtl:space-x-reverse search-modal" data-bs-toggle="modal" data-bs-target="#searchModal">
    <iconify-icon icon="heroicons-outline:search"></iconify-icon>
    <span class="xl:inline-block hidden">Search...
    </span>
</button>