<a class="flex items-center" href="{{ url('/admin/dashboard') }}">
    <img src="{{ asset('images/logo.png') }}" class="black_logo w-10" alt="logo">
    <img src="{{ asset('images/logo.png') }}" class="white_logo w-10" alt="logo">
    <span class="ltr:ml-3 rtl:mr-3 text-xl font-Inter font-bold text-slate-900 dark:text-white">Admin Panel</span>
</a>
