<a class="flex items-center" href="{{ url('/dashboard') }}">
    <img src="{{ asset('images/logo.png') }}" class="white_logo w-10" alt="logo">
    <span class="ltr:ml-3 rtl:mr-3 text-xl font-Inter font-bold text-slate-900 ">City Bank</span>
</a>
