Drop the DashCode starterkit assets into public/dashcode.
Expected structure:
- public/dashcode/assets/css/*.css
- public/dashcode/assets/js/*.js
- public/dashcode/assets/images/**/*

From your folder: DashCode HTML-v1.0.0/dashcode-html/dashcode-html-starterkit/assets/**
