<div class="z-[9] sticky top-0" id="app_header">
    <div class="app-header z-[999] bg-white dark:bg-slate-800 shadow-sm dark:shadow-slate-700">
        <div class="flex justify-between items-center h-full">
            <div class="flex items-center md:space-x-4 space-x-4 rtl:space-x-reverse vertical-box">
                <div class="xl:hidden inline-block">
                    <?php if (isset($component)) { $__componentOriginal02fd23cd52dd6db0366117f88be28355 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal02fd23cd52dd6db0366117f88be28355 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.application-logo','data' => ['class' => 'mobile-logo']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mobile-logo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal02fd23cd52dd6db0366117f88be28355)): ?>
<?php $attributes = $__attributesOriginal02fd23cd52dd6db0366117f88be28355; ?>
<?php unset($__attributesOriginal02fd23cd52dd6db0366117f88be28355); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02fd23cd52dd6db0366117f88be28355)): ?>
<?php $component = $__componentOriginal02fd23cd52dd6db0366117f88be28355; ?>
<?php unset($__componentOriginal02fd23cd52dd6db0366117f88be28355); ?>
<?php endif; ?>
                </div>
                <button class="smallDeviceMenuController  open-sdiebar-controller hidden xl:hidden md:inline-block">
                    <iconify-icon
                        class="leading-none bg-transparent relative text-xl top-[2px] text-slate-900 dark:text-white"
                        icon="heroicons-outline:menu-alt-3"></iconify-icon>
                </button>
            </div>
            <!-- end vertcial -->

            <div class="items-center space-x-4 rtl:space-x-reverse horizental-box">

                <button class="smallDeviceMenuController  open-sdiebar-controller  hidden xl:hidden md:inline-block">
                    <iconify-icon
                        class="leading-none bg-transparent relative text-xl top-[2px] text-slate-900 dark:text-white"
                        icon="heroicons-outline:menu-alt-3"></iconify-icon>
                </button>
            </div>
            <!-- end horizontal -->

            <!-- start horizontal nav -->
            <!-- end horizontal nav -->
            <div class="nav-tools flex items-center lg:space-x-5 space-x-3 rtl:space-x-reverse leading-0">
                <?php if (isset($component)) { $__componentOriginal62340ea5939bae2d07467d5299bd641e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62340ea5939bae2d07467d5299bd641e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dark-light','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dark-light'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62340ea5939bae2d07467d5299bd641e)): ?>
<?php $attributes = $__attributesOriginal62340ea5939bae2d07467d5299bd641e; ?>
<?php unset($__attributesOriginal62340ea5939bae2d07467d5299bd641e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62340ea5939bae2d07467d5299bd641e)): ?>
<?php $component = $__componentOriginal62340ea5939bae2d07467d5299bd641e; ?>
<?php unset($__componentOriginal62340ea5939bae2d07467d5299bd641e); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal9deb25ca8a7c19027764b22ecddc8641 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9deb25ca8a7c19027764b22ecddc8641 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-message-dropdown','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-message-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9deb25ca8a7c19027764b22ecddc8641)): ?>
<?php $attributes = $__attributesOriginal9deb25ca8a7c19027764b22ecddc8641; ?>
<?php unset($__attributesOriginal9deb25ca8a7c19027764b22ecddc8641); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9deb25ca8a7c19027764b22ecddc8641)): ?>
<?php $component = $__componentOriginal9deb25ca8a7c19027764b22ecddc8641; ?>
<?php unset($__componentOriginal9deb25ca8a7c19027764b22ecddc8641); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal0a1d69d641eb62d53897911dee67d688 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a1d69d641eb62d53897911dee67d688 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-notification-dropdown','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-notification-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a1d69d641eb62d53897911dee67d688)): ?>
<?php $attributes = $__attributesOriginal0a1d69d641eb62d53897911dee67d688; ?>
<?php unset($__attributesOriginal0a1d69d641eb62d53897911dee67d688); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a1d69d641eb62d53897911dee67d688)): ?>
<?php $component = $__componentOriginal0a1d69d641eb62d53897911dee67d688; ?>
<?php unset($__componentOriginal0a1d69d641eb62d53897911dee67d688); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalaab9145b5828d591c604e3a035016afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaab9145b5828d591c604e3a035016afe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.nav-user-dropdown','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.nav-user-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaab9145b5828d591c604e3a035016afe)): ?>
<?php $attributes = $__attributesOriginalaab9145b5828d591c604e3a035016afe; ?>
<?php unset($__attributesOriginalaab9145b5828d591c604e3a035016afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaab9145b5828d591c604e3a035016afe)): ?>
<?php $component = $__componentOriginalaab9145b5828d591c604e3a035016afe; ?>
<?php unset($__componentOriginalaab9145b5828d591c604e3a035016afe); ?>
<?php endif; ?>
                <button class="smallDeviceMenuController md:hidden block leading-0">
                    <iconify-icon class="cursor-pointer text-slate-900 dark:text-white text-2xl"
                        icon="heroicons-outline:menu-alt-3"></iconify-icon>
                </button>
                <!-- end mobile menu -->
            </div>

            <!-- end nav tools -->

        </div>
    </div>
</div>

<!-- BEGIN: Search Modal -->
<div class="modal fade fixed top-0 left-0 hidden w-full h-full outline-none overflow-x-hidden overflow-y-auto inset-0 bg-slate-900/40 backdrop-filter backdrop-blur-sm backdrop-brightness-10"
    id="searchModal" tabindex="-1" aria-labelledby="searchModalLabel" aria-hidden="true">
    <div class="modal-dialog relative w-auto pointer-events-none top-1/4">
        <div
            class="modal-content border-none shadow-lg relative flex flex-col w-full pointer-events-auto bg-white dark:bg-slate-900 bg-clip-padding rounded-md outline-none text-current">
            <form>
                <div class="relative">
                    <button
                        class="absolute left-0 top-1/2 -translate-y-1/2 w-9 h-full text-xl dark:text-slate-300 flex items-center justify-center">
                        <iconify-icon icon="heroicons-solid:search"></iconify-icon>
                    </button>
                    <input type="text" class="form-control !py-[14px] !pl-10" placeholder="Search" autofocus>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- END: Search Modal -->
<?php /**PATH D:\city-bank-loan\city-bank-loan\resources\views/components/admin/dashboard-header.blade.php ENDPATH**/ ?>