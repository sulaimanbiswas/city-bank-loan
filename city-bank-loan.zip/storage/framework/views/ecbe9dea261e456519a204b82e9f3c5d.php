<div class="sidebar-wrapper group">
    <div id="bodyOverlay" class="w-screen h-screen fixed top-0 bg-slate-900 bg-opacity-50 backdrop-blur-sm z-10 hidden">
    </div>
    <div class="logo-segment">
        <?php if (isset($component)) { $__componentOriginal02fd23cd52dd6db0366117f88be28355 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal02fd23cd52dd6db0366117f88be28355 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.application-logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal02fd23cd52dd6db0366117f88be28355)): ?>
<?php $attributes = $__attributesOriginal02fd23cd52dd6db0366117f88be28355; ?>
<?php unset($__attributesOriginal02fd23cd52dd6db0366117f88be28355); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal02fd23cd52dd6db0366117f88be28355)): ?>
<?php $component = $__componentOriginal02fd23cd52dd6db0366117f88be28355; ?>
<?php unset($__componentOriginal02fd23cd52dd6db0366117f88be28355); ?>
<?php endif; ?>
        <!-- Sidebar Type Button -->
        <div id="sidebar_type" class="cursor-pointer text-slate-900 dark:text-white text-lg">
            <iconify-icon class="sidebarDotIcon extend-icon text-slate-900 dark:text-slate-200"
                icon="fa-regular:dot-circle"></iconify-icon>
            <iconify-icon class="sidebarDotIcon collapsed-icon text-slate-900 dark:text-slate-200"
                icon="material-symbols:circle-outline"></iconify-icon>
        </div>
        <button class="sidebarCloseIcon text-2xl">
            <iconify-icon class="text-slate-900 dark:text-slate-200" icon="clarity:window-close-line"></iconify-icon>
        </button>
    </div>
    <div id="nav_shadow"
        class="nav_shadow h-[60px] absolute top-[80px] nav-shadow z-[1] w-full transition-all duration-200 pointer-events-none
      opacity-0">
    </div>
    <div class="sidebar-menus bg-white dark:bg-slate-800 py-2 px-4 h-[calc(100%-80px)] overflow-y-auto z-50"
        id="sidebar_menus">
        <ul class="sidebar-menu">
            <li class="sidebar-menu-title uppercase">MENU</li>
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                    class="navItem <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
                    <span class="flex items-center">
                        <iconify-icon class=" nav-icon" icon="heroicons-outline:home"></iconify-icon>
                        <span>Home</span>
                    </span>
                </a>
            </li>
            <li>
                <a href="#" class="navItem">
                    <span class="flex items-center">
                        <iconify-icon class=" nav-icon" icon="heroicons-outline:cog-6-tooth"></iconify-icon>
                        <span>Settings</span>
                    </span>
                    <iconify-icon class="icon-arrow" icon="heroicons-outline:chevron-right"></iconify-icon>
                </a>
                <ul class="sidebar-submenu">
                    <li>
                        <a href="<?php echo e(route('admin.site-settings.index')); ?>"
                            class="<?php echo e(request()->routeIs('admin.site-settings.*') ? 'active' : ''); ?>">Site Settings</a>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- Upgrade Your Business Plan Card Start -->
        <!-- <div class="bg-slate-900 mb-10 mt-24 p-4 relative text-center rounded-2xl text-white" id="sidebar_bottom_wizard">
            <img src="assets/images/svg/rabit.svg" alt="" class="mx-auto relative -mt-[73px]">
            <div class="max-w-[160px] mx-auto mt-6">
                <div class="widget-title font-Inter mb-1">Unlimited Access</div>
                <div class="text-xs font-light font-Inter">
                    Upgrade your system to business plan
                </div>
            </div>
            <div class="mt-6">
                <button class="bg-white hover:bg-opacity-80 text-slate-900 text-sm font-Inter rounded-md w-full block py-2 font-medium">
                    Upgrade
                </button>
            </div>
        </div> -->
        <!-- Upgrade Your Business Plan Card Start -->
    </div>
</div>
<?php /**PATH D:\city-bank-loan\city-bank-loan\resources\views/components/admin/sidebar-menu.blade.php ENDPATH**/ ?>