

<?php $__env->startSection('title', 'প্রোফাইল'); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-3xl mx-auto space-y-6">
        <div class="p-4 sm:p-6 bg-white shadow rounded">
            <div class="max-w-xl">
                <?php echo $__env->make('profile.partials.update-profile-information-form', ['user' => $user], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
        <div class="p-4 sm:p-6 bg-white shadow rounded">
            <div class="max-w-xl">
                <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
        <div class="p-4 sm:p-6 bg-white shadow rounded">
            <div class="max-w-xl">
                <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
    <?php if(session('status') === 'profile-updated'): ?>
    <div class="mt-4 text-green-600 text-sm">প্রোফাইল আপডেট হয়েছে।</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\city-bank-loan\city-bank-loan\resources\views/profile/edit_user.blade.php ENDPATH**/ ?>