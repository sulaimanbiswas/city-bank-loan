<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="ltr" class="dark nav-floating">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Admin')); ?> — <?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

    <!-- BEGIN: Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <!-- END: Google Font -->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/sidebar-menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/SimpleBar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/app.css')); ?>">
    <!-- END: Theme CSS-->
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>

    <script src="<?php echo e(asset('admin/assets/js/settings.js')); ?>" sync></script>
</head>

<body class="font-inter dashcode-app" id="body_class">
    <!-- Preloader -->
    
    <div class="app-wrapper h-screen">
        <?php if (isset($component)) { $__componentOriginale12ea347a6cdb41eed5c169e91dbeeac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale12ea347a6cdb41eed5c169e91dbeeac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.sidebar-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale12ea347a6cdb41eed5c169e91dbeeac)): ?>
<?php $attributes = $__attributesOriginale12ea347a6cdb41eed5c169e91dbeeac; ?>
<?php unset($__attributesOriginale12ea347a6cdb41eed5c169e91dbeeac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale12ea347a6cdb41eed5c169e91dbeeac)): ?>
<?php $component = $__componentOriginale12ea347a6cdb41eed5c169e91dbeeac; ?>
<?php unset($__componentOriginale12ea347a6cdb41eed5c169e91dbeeac); ?>
<?php endif; ?>
        <div class="app-content flex-1 ">
            <!-- BEGIN: header -->
            <?php if (isset($component)) { $__componentOriginal5b7167194f25d0276435bec76be9adad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b7167194f25d0276435bec76be9adad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.dashboard-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.dashboard-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b7167194f25d0276435bec76be9adad)): ?>
<?php $attributes = $__attributesOriginal5b7167194f25d0276435bec76be9adad; ?>
<?php unset($__attributesOriginal5b7167194f25d0276435bec76be9adad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b7167194f25d0276435bec76be9adad)): ?>
<?php $component = $__componentOriginal5b7167194f25d0276435bec76be9adad; ?>
<?php unset($__componentOriginal5b7167194f25d0276435bec76be9adad); ?>
<?php endif; ?>
            <!-- BEGIN: header -->
            <div class="content-wrapper  transition-all duration-150 ltr:ml-[248px] rtl:mr-[248px]"
                id="content_wrapper">
                <div class="page-content ">
                    <div class="transition-all duration-150 container-fluid" id="page_layout">
                        <main id="content_layout">
                            <!-- Page Content -->
                            <?php echo $__env->yieldContent('content'); ?>
                        </main>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!-- Core Js -->
    <script src="<?php echo e(asset('admin/assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/tw-elements-1.0.0-alpha13.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/SimpleBar.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/iconify.js')); ?>"></script>
    <!-- Jquery Plugins -->

    <!-- app js -->
    <script src="<?php echo e(asset('admin/assets/js/sidebar-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/app.js')); ?>"></script>
    <script>
        // Hide preloader when admin assets and page are loaded
        window.addEventListener('load', function() {
            var el = document.getElementById('app-preloader');
            if (el) {
                el.classList.add('opacity-0', 'pointer-events-none');
                setTimeout(function() {
                    el.style.display = 'none';
                }, 300);
            }
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\city-bank-loan\city-bank-loan\resources\views/layouts/admin.blade.php ENDPATH**/ ?>