<header
    style="background-image: url('../public/topimg.jpg')"
    class="mb-2">
    <div class="">
        <img src="/public/main_logo.jpg" alt="" />
    </div>
</header><?php /**PATH D:\city-bank-loan\city-bank-loan\resources\views/layouts/user/header.blade.php ENDPATH**/ ?>