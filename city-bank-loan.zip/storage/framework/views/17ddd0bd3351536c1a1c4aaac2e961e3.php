<a class="flex items-center" href="<?php echo e(url('/admin/dashboard')); ?>">
    <img src="<?php echo e(asset('images/logo.png')); ?>" class="black_logo w-10" alt="logo">
    <img src="<?php echo e(asset('images/logo.png')); ?>" class="white_logo w-10" alt="logo">
    <span class="ltr:ml-3 rtl:mr-3 text-xl font-Inter font-bold text-slate-900 dark:text-white">Admin Panel</span>
</a>
<?php /**PATH D:\city-bank-loan\city-bank-loan\resources\views/components/admin/application-logo.blade.php ENDPATH**/ ?>